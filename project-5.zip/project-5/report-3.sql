SET ECHO ON
SET LINESIZE 100
SET PAGESIZE 66
CLEAR COLUMNS
CLEAR BREAKS
SPOOL D:\DB\Project\report-3.txt

TTITLE CENTER 'Reservations x Payment Type' SKIP 2
BTITLE OFF

COLUMN rpaid FORMAT $9,990.00 HEADING 'Reservation Price'
COLUMN tpaid FORMAT $9,990.00 HEADING 'Tax'
COLUMN tpaid_p FORMAT 990.00 HEADING 'Tax %'
COLUMN rcc FORMAT $9,990.00 HEADING 'Credit Card'
COLUMN rcc_p FORMAT 990.00 HEADING 'Credit Card %'
COLUMN rpromo FORMAT $9,990.00 HEADING 'Promocode'
COLUMN rpromo_p FORMAT 990.00 HEADING 'Promocode %'

SELECT SUM(reservation_green_fees_total_paid) rpaid,
SUM(Reservation_tax_paid) tpaid,
(SUM(Reservation_tax_paid) / SUM(reservation_green_fees_total_paid)) * 100 tpaid_p,
SUM(Reservation_amount_charged_cc) rcc,
(SUM(Reservation_amount_charged_cc) / (SUM(Reservation_green_fees_total_paid) + SUM(Reservation_tax_paid))) * 100 rcc_p,
SUM(promocode_value) rpromo,
(SUM(promocode_value) / (SUM(Reservation_green_fees_total_paid) + SUM(Reservation_tax_paid)) * 100) rpromo_p
FROM reservation r
LEFT OUTER JOIN promocode p ON p.promocode_reservation_id = r.reservation_id;


CLEAR COLUMNS

SPOOL OFF





