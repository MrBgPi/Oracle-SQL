SET ECHO ON
SET VERIFY OFF
SET FEEDBACK OFF
SET LINESIZE 60
SET PAGESIZE 60
CLEAR COLUMNS

SPOOL D:\DB\Project\report-2.txt

-- Report: The Three Highest Ranked Tee Times

TTITLE CENTER 'The Three Highest Ranked Tee Times' SKIP 2
BTITLE OFF


SELECT tt_tee_time_id "Tee Time ID",
TO_CHAR(tt_time, 'DD-MON-YY HH:MM') "Tee Date/Time",
TO_CHAR(tt_price, '$9,990.00') "Tee Price",
AVG(review_rating) "Rating"
FROM review r
JOIN reservation r1 ON r1.reservation_id = r.review_reservation_id
JOIN tee_time t on t.tt_tee_time_id = r1.reservation_tee_time_id
GROUP BY review_reservation_id, tt_tee_time_id, tt_time, tt_price
ORDER BY AVG(review_rating) DESC
FETCH FIRST 3 ROWS ONLY;


CLEAR COLUMNS

SPOOL OFF
