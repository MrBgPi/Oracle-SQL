SET ECHO ON
SET VERIFY OFF
SET FEEDBACK OFF
SET LINESIZE 100
SET PAGESIZE 90
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES
SET UNDERLINE OFF

SPOOL D:\DB\Project\report-1.txt

-- Report: Most popular Tee Times by Course

TTITLE CENTER 'Most popular Tee Times by Course' RIGHT 'Page: ' SQL.PNO SKIP 2
BTITLE OFF

BREAK ON coursename ON teetime;

COMPUTE AVG LABEL 'Average' OF teeprice ON coursename;
COMPUTE AVG LABEL 'Average' OF nreservations ON coursename;

COLUMN coursename FORMAT A40 HEADING 'Course Name|----------------------------------------'
COLUMN teetime FORMAT A20 HEADING 'Tee Date/Time|--------------------'
COLUMN teeprice FORMAT $9,990.00 HEADING 'Tee Price|-------------'
COLUMN nreservations FORMAT 990 HEADING '# of|Reservations|-------------'


ACCEPT course_name CHAR PROMPT "Enter Course Name:"

SELECT course_name coursename,
TO_CHAR(tt_time, 'DD-MON-YY HH:MM') teetime,
tt_price teeprice,
NVL((SELECT COUNT(*)
 FROM reservation r
 GROUP BY reservation_tee_time_id
 HAVING r.reservation_tee_time_id = t.tt_tee_time_id),0) nreservations
FROM tee_time t 
JOIN course c ON c.course_id = t.tt_course_id
WHERE UPPER(course_name) LIKE (UPPER('%&COURSE_NAME%'))
ORDER BY course_name, nreservations DESC;

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

SPOOL OFF