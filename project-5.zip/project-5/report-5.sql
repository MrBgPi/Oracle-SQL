SET ECHO ON
SET VERIFY OFF
SET FEEDBACK OFF
SET LINESIZE 120
SET PAGESIZE 90
CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES
SET UNDERLINE OFF

SPOOL D:\DB\Project\report-5.txt

-- Report: Courses by Province

TTITLE CENTER 'Courses by Province' RIGHT 'Page: ' SQL.PNO SKIP 2
BTITLE OFF

BREAK ON province ON coursename ON report;

COMPUTE AVG LABEL 'Average' OF teeprice ON province;
COMPUTE AVG LABEL 'Average' OF rating ON province;
COMPUTE AVG LABEL 'Average' OF ratingprovince ON province;
COMPUTE AVG LABEL 'Average' OF favouritecustomers ON province;
COMPUTE SUM LABEL 'Total' OF province ON report;

COLUMN province FORMAT A20 HEADING 'Province|--------------------'
COLUMN coursename FORMAT A39 HEADING 'Course Name|---------------------------------------'
COLUMN rating FORMAT 990.00 HEADING 'Rating|-------------'
COLUMN ratingprovince FORMAT 990.00 HEADING 'Rating Avg|in Province|-------------'
COLUMN favouritecustomers FORMAT 990 HEADING 'Favourite of|# Customers|-------------'
COLUMN teeprice FORMAT $9,990.00 HEADING 'Tee time|Avg price|-------------'

SELECT DECODE(course_province, 'AB','Alberta','BC','British Columbia','MB','Manitoba','NB',
'New Brunswick','NL','Newfoundland and Labrador','NS','Nova Scotia','NT','Northwest Territories',
'NU','Nunavut','ON','Ontario','PE','Prince Edward Island','QC','Quebec','SK','Saskatchewan','YT','Yukon', '') province,
course_name coursename,
course_average_rating rating,
ROUND((SELECT AVG(course_average_rating)
       FROM course ci
       GROUP BY course_province
       HAVING ci.course_province = c.course_province), 2) ratingprovince,
COUNT(fc.fc_course_id) favouritecustomers,
ROUND((SELECT AVG(tt_price)
       FROM tee_time ti
       GROUP BY tt_course_id
       HAVING ti.tt_course_id = c.course_id), 2) teeprice
FROM course c
LEFT OUTER JOIN favourite_course fc ON fc.fc_course_id = c.course_id
GROUP BY course_province, course_id, course_name, course_city, course_average_rating
ORDER BY province, course_average_rating DESC;

CLEAR COLUMNS
CLEAR BREAKS
CLEAR COMPUTES

SPOOL OFF
