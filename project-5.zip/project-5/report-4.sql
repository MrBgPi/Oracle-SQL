SET ECHO ON
SET VERIFY OFF
SET FEEDBACK OFF
SET LINESIZE 60
SET PAGESIZE 60
CLEAR COLUMNS
SET UNDERLINE OFF

SPOOL D:\DB\Project\report-4.txt

TTITLE CENTER 'Customers with more reservations' SKIP 2
BTITLE OFF

SELECT INITCAP(customer_first_name || ' ' || customer_last_name) "Customer Name",
COUNT(reservation_id) "# of Reservations"
FROM customer c
JOIN reservation r ON r.reservation_customer_id = c.customer_id
GROUP BY INITCAP(customer_first_name || ' ' || customer_last_name)
HAVING COUNT(reservation_id) >= (SELECT MAX(COUNT(reservation_id))
                                 FROM reservation
                                 GROUP BY reservation_customer_id);
                                 
CLEAR COLUMNS
SPOOL OFF