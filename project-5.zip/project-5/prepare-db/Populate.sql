-- DELETE DATA EXISTING IN THE TABLES
DELETE FROM Promocode;
DELETE FROM Review;
DELETE FROM Favourite_Course;
DELETE FROM Reservation;
DELETE FROM Credit_Card;
DELETE FROM Tee_Time;
DELETE FROM Course;
DELETE FROM Customer;

-- POPULATING TABLES

-- Customer
INSERT INTO Customer (customer_id, customer_first_name, customer_last_name, customer_email, customer_gift_card_amount)
VALUES (1, 'Reed', 'Green', 'reed.green@gmail.com', 50.00);
INSERT INTO Customer (customer_id, customer_first_name, customer_last_name, customer_email, customer_gift_card_amount)
VALUES (2, 'Jaime', 'Johnston', 'jaime.johnston@gmail.com', 70.00);
INSERT INTO Customer (customer_id, customer_first_name, customer_last_name, customer_email, customer_gift_card_amount)
VALUES (3, 'Alex', 'Day', 'alex.day@gmail.com', 15.00);

-- Credit Card
INSERT INTO Credit_Card (credit_card_id, credit_card_customer_id, credit_card_name_on_card, credit_card_number, credit_card_expiration_date, credit_card_default_card)
VALUES (1, '1', 'Reed Green', 2221007104860204, '2612', 'N');
INSERT INTO Credit_Card (credit_card_id, credit_card_customer_id, credit_card_name_on_card, credit_card_number, credit_card_expiration_date, credit_card_default_card)
VALUES (2, '1', 'R. Green', 3542048373824588, '2306', 'Y');

INSERT INTO Credit_Card (credit_card_id, credit_card_customer_id, credit_card_name_on_card, credit_card_number, credit_card_expiration_date, credit_card_default_card)
VALUES (3, '2', 'J.Johnston', 6763973066824147, '2208', 'Y');

INSERT INTO Credit_Card (credit_card_id, credit_card_customer_id, credit_card_name_on_card, credit_card_number, credit_card_expiration_date, credit_card_default_card)
VALUES (4, '3', 'Alex Day', 5020508854574107, '2405', 'Y');
INSERT INTO Credit_Card (credit_card_id, credit_card_customer_id, credit_card_name_on_card, credit_card_number, credit_card_expiration_date, credit_card_default_card)
VALUES (5, '3', 'Day A.', 5463434717109946, '2701', 'N');


-- Course
INSERT INTO Course (course_ID, course_name, course_city, course_province, course_postal_code, course_country, course_average_rating, course_description, course_year_build, course_length)
VALUES (1, 'Royce Brook Golf Club', 'Hillsborough', 'ON', 'K0C1X0', 'CA', 73.6, 'Don`t miss out on playing two of New Jersey`s best golf courses - the East and West courses of Royce Brook Golf Club - both offering golfers a fun and enjoyable golf experience. Royce Brook is certified as Cooperative Sanctuary by Audubon International. The course is committed to protecting our local environment, conserving natural resources, and providing wildlife habitats.', 1998, 6946);
INSERT INTO Course (course_ID, course_name, course_city, course_province, course_postal_code, course_country, course_average_rating, course_description, course_year_build, course_length)
VALUES (2, 'Cumberland Trail Golf Club', 'Pataskala', 'AB', 'T8R0K3', 'CA', 73.7, 'Cumberland Trail Golf Club is a par-72, Championship layout course that was designed by the Hurdzan/Fry Design team in the year 2000. The golf course offers five different sets of tees tipping it to over 7,200 yards providing an equal challenge for any golfer. Since its opening, Cumberland Trail Golf Club has been known for having the "Best Greens in Columbus." Cumberland not only provides the experience of putting on tour greens, it now provides the overall golf experience every golfer desires when they step out of their car at the golf course.', 1999, 7205);
INSERT INTO Course (course_ID, course_name, course_city, course_province, course_postal_code, course_country, course_average_rating, course_description, course_year_build, course_length)
VALUES (3, 'Raccoon International Golf Club', 'Granville', 'BC', 'V1E1A7', 'CA', 70.6, 'Raccoon International is a mature course located 20 minutes East of Columbus Ohio. Situated in rolling woodlands just outside of historic Granville, it features striking vistas and beautiful lakes on a challenging and beautifully maintained par 72 layout. Among the most memorable holes are #8 (a par four from a dramatic elevated tee that requires a tee shot as long as 220 yards to clear the lake), #11 (a 121 yard par 3 over a lake to a two tiered green guarded by a meandering bunker), and the notorious #17 (a par 5 that plays a devilish 666 yards from the back tees) You can choose from four sets of tees to give you the best golf experience for your skill level. If you are interested in working on your skill level, we have a full driving range and a practice green.', 1972, 6586);
INSERT INTO Course (course_ID, course_name, course_city, course_province, course_postal_code, course_country, course_average_rating, course_description, course_year_build, course_length)
VALUES (4, 'Chapel Hill Golf Club', 'Mount Vernon', 'AB', 'T9V3N9', 'CA', 72.6, 'Forest Hills is an exciting 18 hole executive course located at the Forest Hills Golf Course facility in Mansfield, OH. From the longest tees it presents 2,698 yards of golf for a par of 56. The course was designed by and opened in 1962. The course rating is 70.0 with a slope rating of 113. The course contact is Scott Thompson, Owner.', 1996, 6856);
INSERT INTO Course (course_ID, course_name, course_city, course_province, course_postal_code, course_country, course_average_rating, course_description, course_year_build, course_length)
VALUES (5, 'Forest Hills Golf Club', 'Mansfield', 'ON', 'K2G5N5', 'CA', 70.0, 'Situated only 35 miles Northeast of Columbus, Ohio, Chapel Hill`s central location makes it very convenient from anywhere. This 6,950 yard Barry Serafin -designed golf course, with a slope of 125, provides a fun, but challenging test of golf for all players. (You can see more course statistics here.) Chapel Hill Golf Course opened in 1996 on the former site of the Mount Vernon Bible College. The Chapel that once served as a place of worship was converted into a unique, one-of-a-kind clubhouse. Stocked with all the latest merchandise, the Pro Shop at Chapel Hill is a great place to pick up balls, tees, and other supplies, or even a souvenir after your round.', 1962, 2698);

-- Tee_Time
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (1, TO_DATE('2022-02-20 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-20', 'YYYY-MM-DD'), 75.00, 'N', 9, 1);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (2, TO_DATE('2022-02-20 11:10:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-20', 'YYYY-MM-DD'), 75.00, 'N', 9, 1);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (3, TO_DATE('2022-02-20 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-20', 'YYYY-MM-DD'), 50.00, 'N', 9, 1);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (4, TO_DATE('2022-02-24 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 20.50, 'Y', 9, 2);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (5, TO_DATE('2022-02-24 10:58:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 20.50, 'N', 9, 2);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (6, TO_DATE('2022-02-24 11:07:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 20.50, 'N', 9, 2);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (7, TO_DATE('2022-02-24 10:40:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 19.80, 'N', 18, 3);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (8, TO_DATE('2022-02-24 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 19.80, 'N', 18, 3);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (9, TO_DATE('2022-02-24 18:24:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-24', 'YYYY-MM-DD'), 19.80, 'N', 18, 3);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (10, TO_DATE('2022-02-25 07:26:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-25', 'YYYY-MM-DD'), 27.00, 'N', 18, 4);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (11, TO_DATE('2022-02-25 11:02:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-25', 'YYYY-MM-DD'), 27.00, 'N', 18, 4);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (12, TO_DATE('2022-02-25 14:06:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-25', 'YYYY-MM-DD'), 27.00, 'N', 18, 4);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (13, TO_DATE('2022-02-23 08:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-23', 'YYYY-MM-DD'), 10.00, 'N', 9, 5);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (14, TO_DATE('2022-02-23 09:45:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-23', 'YYYY-MM-DD'), 10.00, 'N', 9, 5);
INSERT INTO Tee_Time (TT_tee_time_id, TT_time, TT_date, TT_price, TT_is_cart_included, TT_number_of_holes, TT_course_id)
VALUES (15, TO_DATE('2022-02-23 11:15:00', 'YYYY-MM-DD HH24:MI:SS'), TO_DATE('2022-02-23', 'YYYY-MM-DD'), 10.00, 'N', 9, 5);

-- Reservation
INSERT INTO Reservation (Reservation_id, Reservation_customer_id, Reservation_tee_time_id, Reservation_credit_card_id, Reservation_number_of_players, Reservation_green_fees_total_paid, Reservation_tax_paid, Reservation_amount_charged_cc)
VALUES (1, 3, 10, 4, 5, 135.00, 5.00, 140.00);
INSERT INTO Reservation (Reservation_id, Reservation_customer_id, Reservation_tee_time_id, Reservation_credit_card_id, Reservation_number_of_players, Reservation_green_fees_total_paid, Reservation_tax_paid, Reservation_amount_charged_cc)
VALUES (2, 2, 9, 2, 1, 19.80, 1.50, 0.00);
INSERT INTO Reservation (Reservation_id, Reservation_customer_id, Reservation_tee_time_id, Reservation_credit_card_id, Reservation_number_of_players, Reservation_green_fees_total_paid, Reservation_tax_paid, Reservation_amount_charged_cc)
VALUES (3, 1, 2, 2, 9, 500.00, 50.00, 400.00);
INSERT INTO Reservation (Reservation_id, Reservation_customer_id, Reservation_tee_time_id, Reservation_credit_card_id, Reservation_number_of_players, Reservation_green_fees_total_paid, Reservation_tax_paid, Reservation_amount_charged_cc)
VALUES (4, 3, 10, 4, 1, 27.00, 2.75, 29.75);
INSERT INTO Reservation (Reservation_id, Reservation_customer_id, Reservation_tee_time_id, Reservation_credit_card_id, Reservation_number_of_players, Reservation_green_fees_total_paid, Reservation_tax_paid, Reservation_amount_charged_cc)
VALUES (5, 1, 15, 2, 1, 10.00, 1.00, 11.00);

-- Promocode
INSERT INTO Promocode (promocode_id, promocode_customer_id, promocode_reservation_id, promocode_date_issued, promocode_value, promocode_expire_date, promocode_is_used)
VALUES (1, 1, 3, TO_DATE('2022-01-01', 'YYYY-MM-DD'), 100.00, TO_DATE('2022-03-31', 'YYYY-MM-DD'), 'Y');
INSERT INTO Promocode (promocode_id, promocode_customer_id, promocode_reservation_id, promocode_date_issued, promocode_value, promocode_expire_date, promocode_is_used)
VALUES (2, 3, NULL, TO_DATE('2022-01-15', 'YYYY-MM-DD'), 15.00, TO_DATE('2022-03-15', 'YYYY-MM-DD'), 'N');
INSERT INTO Promocode (promocode_id, promocode_customer_id, promocode_reservation_id, promocode_date_issued, promocode_value, promocode_expire_date, promocode_is_used)
VALUES (3, 2, 2, TO_DATE('2022-01-01', 'YYYY-MM-DD'), 21.30, TO_DATE('2022-03-31', 'YYYY-MM-DD'), 'Y');
INSERT INTO Promocode (promocode_id, promocode_customer_id, promocode_reservation_id, promocode_date_issued, promocode_value, promocode_expire_date, promocode_is_used)
VALUES (4, 1, NULL, TO_DATE('2022-02-01', 'YYYY-MM-DD'), 50.00, TO_DATE('2022-02-28', 'YYYY-MM-DD'), 'N');
INSERT INTO Promocode (promocode_id, promocode_customer_id, promocode_reservation_id, promocode_date_issued, promocode_value, promocode_expire_date, promocode_is_used)
VALUES (5, 2, NULL, TO_DATE('2022-02-01', 'YYYY-MM-DD'), 70.00, TO_DATE('2022-02-28', 'YYYY-MM-DD'), 'N');

-- Favourite_Course
INSERT INTO Favourite_Course (FC_customer_ID, FC_course_ID)
VALUES (1, 3);
INSERT INTO Favourite_Course (FC_customer_ID, FC_course_ID)
VALUES (1, 5);
INSERT INTO Favourite_Course (FC_customer_ID, FC_course_ID)
VALUES (3, 4);
INSERT INTO Favourite_Course (FC_customer_ID, FC_course_ID)
VALUES (3, 4);


-- Review
INSERT INTO Review (review_ID, review_course_ID, review_Reservation_ID, review_rating, review_title, review_comments)
VALUES (1, 4, 1, 5, 'Awesome!', 'I had a lot o fun there!');
INSERT INTO Review (review_ID, review_course_ID, review_Reservation_ID, review_rating, review_title, review_comments)
VALUES (2, 1, 3, 1, 'Poor, the bad one ever!', 'It was raining, how could they allowed that!!!');
INSERT INTO Review (review_ID, review_course_ID, review_Reservation_ID, review_rating, review_title, review_comments)
VALUES (3, 5, 5, 3, 'Good', 'The beer was not too cold!');

COMMIT;