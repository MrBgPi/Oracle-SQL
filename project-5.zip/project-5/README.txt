This file contains the instructions to prepare the Oracle database and to run the reports.

****************
1-DB Preparation
****************

In order to have the database structure of the Forever Golf and data available to run the reports, the following script must be run in the presented order:

- Create tables
Run the script file \prepare-db\BuildDB.sql

- Populate tables
Run the script file \prepare-db\Populate.sql

****************
2-Reports
****************

1.Most popular Tee Times by Course
Displays the tee times grouped by course and ordered according to the number of reservations, the user must provide the course name as input.
Script to run: report-1.sql
Sample report: report-1.txt

2.The Three Highest Ranked Tee Times
Display the three tee times with the highest average rating.
Script to run: report-2.sql
Sample report: report-2.txt

3.Reservations x Payment Type
Displays the reservations and the used payment types.
Script to run: report-3.sql
Sample report: report-3.txt

4.Customers with more reservations
Display the customer or customers with the maximum number of reservations.
Script to run: report-4.sql
Sample report: report-4.txt

5.Courses by Province
Display the courses by province, ratings and average for the province, how many customer added as favourite and the average price of the tee time.
Script to run: report-5.sql
Sample report: report-5.txt